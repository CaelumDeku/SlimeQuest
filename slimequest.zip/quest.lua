local quest = {}
quest.panel= love.graphics.newImage("picture/GUI/dialogue.png")

quest.faces = {}
quest.faces.slime = love.graphics.newImage("picture/faces/slime.png")
quest.faces.pixie = love.graphics.newImage("picture/faces/pixie.png")
quest.faces.witch = love.graphics.newImage("picture/faces/Witch.png")

function quest.load ()
end
function quest.draw () 
end
return quest